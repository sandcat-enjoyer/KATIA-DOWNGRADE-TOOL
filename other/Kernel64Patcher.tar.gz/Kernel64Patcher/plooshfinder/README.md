# plooshfinder

> WIP modern offset finder
- Very fast
- Only needs a standard library