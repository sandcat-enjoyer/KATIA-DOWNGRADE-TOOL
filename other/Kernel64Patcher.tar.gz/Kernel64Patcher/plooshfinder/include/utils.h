#ifndef _UTILS_H
#define _UTILS_H
#include <stdint.h>

uint32_t convert_endianness32(uint32_t val);

#endif