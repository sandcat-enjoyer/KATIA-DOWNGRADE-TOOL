#include <stdint.h>
#include <stdbool.h>

uint32_t arm64_branch(void *caller, void *target, bool link);